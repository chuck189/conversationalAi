# AI Voice Agent Call Center Dashboard

## Overview

This is a full-stack web application that provides a dashboard for monitoring and managing AI voice agents in a call center environment. The system allows users to start test calls, monitor active conversations in real-time, and view analytics about call performance.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI with shadcn/ui component library
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: TanStack Query (React Query) for server state
- **Real-time Updates**: WebSocket connection for live data

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Real-time Communication**: WebSocket server for broadcasting updates
- **AI Integration**: OpenAI GPT-4o for voice agent conversations

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon serverless
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Schema Location**: Shared schema in `/shared/schema.ts`
- **Migrations**: Drizzle Kit for database migrations
- **In-Memory Fallback**: Memory storage implementation for development

## Key Components

### Database Schema
- **Users**: Authentication and user management
- **Calls**: Call records with customer info, type, status, and timing
- **Conversations**: Message history for each call stored as JSON
- **Customer Profiles**: Customer account information and status
- **Call Stats**: Daily aggregated statistics and metrics

### API Structure
- **REST Endpoints**: 
  - `/api/stats` - Dashboard statistics
  - `/api/calls` - Call management
  - `/api/calls/active` - Active calls monitoring
  - `/api/calls/recent` - Recent call history
  - `/api/calls/:id/conversation` - Conversation data
- **WebSocket**: Real-time updates on `/ws` endpoint

### AI Voice Agent
- **Provider**: OpenAI GPT-4o model
- **Scenarios**: Payment collection, identity verification, account onboarding, issue resolution
- **Context-Aware**: Uses customer profile data for personalized interactions
- **System Prompts**: Tailored prompts for different call scenarios

### Frontend Features
- **Dashboard**: Real-time metrics and active call monitoring
- **Active Calls Panel**: Live view of ongoing conversations
- **Conversation Preview**: Real-time message display
- **Call Simulation**: Test call creation with predefined scenarios
- **Recent Activity**: Historical call log and outcomes

## Data Flow

1. **Call Initiation**: User starts test call through simulation modal
2. **AI Processing**: OpenAI generates contextual responses based on scenario
3. **Real-time Updates**: WebSocket broadcasts conversation updates
4. **Data Persistence**: Conversations and call data stored in PostgreSQL
5. **Dashboard Updates**: React Query refetches data automatically
6. **Statistics Aggregation**: Daily stats calculated and displayed

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **openai**: AI conversation generation
- **ws**: WebSocket server implementation
- **@tanstack/react-query**: Server state management
- **wouter**: Client-side routing

### UI Dependencies
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Frontend build tool and dev server
- **tsx**: TypeScript execution for server
- **esbuild**: Production server bundling

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx for TypeScript execution
- **Database**: Neon serverless PostgreSQL
- **Environment**: Replit-optimized with runtime error overlay

### Production
- **Frontend**: Static build output via Vite
- **Backend**: ESBuild bundled server
- **Database**: Neon PostgreSQL with connection pooling
- **Deployment**: Node.js server serving static files

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: OpenAI API authentication
- `NODE_ENV`: Environment mode (development/production)

## Changelog
- July 01, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.
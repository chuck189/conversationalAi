import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { aiAgent } from "./services/openai";
import { insertCallSchema, insertConversationSchema, type Message, type WSMessage, type CallScenario } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('Client connected to WebSocket');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });
  });

  function broadcast(message: WSMessage) {
    const data = JSON.stringify(message);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }

  // API Routes

  // Get dashboard stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getTodayStats();
      const activeCalls = await storage.getActiveCalls();
      
      if (stats) {
        stats.activeCalls = activeCalls.length;
        await storage.updateStats(stats);
      }

      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Get active calls
  app.get("/api/calls/active", async (req, res) => {
    try {
      const calls = await storage.getActiveCalls();
      res.json(calls);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch active calls" });
    }
  });

  // Get recent calls
  app.get("/api/calls/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const calls = await storage.getRecentCalls(limit);
      res.json(calls);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recent calls" });
    }
  });

  // Start a new call simulation
  app.post("/api/calls/start", async (req, res) => {
    try {
      const { accountId, scenario } = z.object({
        accountId: z.string(),
        scenario: z.enum(["payment", "verification", "onboarding", "support"]),
      }).parse(req.body);

      const customerProfile = await storage.getCustomerProfile(accountId);
      if (!customerProfile) {
        return res.status(404).json({ error: "Customer profile not found" });
      }

      const call = await storage.createCall({
        customerName: customerProfile.name,
        customerPhone: customerProfile.phone,
        accountId: customerProfile.accountId,
        type: scenario,
        status: "active",
        outcome: null,
        aiProcessing: false,
      });

      // Create initial conversation
      const initialMessages: Message[] = [
        {
          id: "1",
          role: "ai",
          content: `Hello, this is VoiceAI calling regarding your account. May I speak with ${customerProfile.name}?`,
          timestamp: new Date().toISOString(),
        }
      ];

      await storage.createConversation({
        callId: call.id,
        messages: initialMessages,
      });

      broadcast({
        type: "new_call",
        data: call,
      });

      res.json(call);
    } catch (error) {
      console.error("Start call error:", error);
      res.status(500).json({ error: "Failed to start call" });
    }
  });

  // Get call conversation
  app.get("/api/calls/:id/conversation", async (req, res) => {
    try {
      const callId = parseInt(req.params.id);
      const conversation = await storage.getConversation(callId);
      
      if (!conversation) {
        return res.status(404).json({ error: "Conversation not found" });
      }

      res.json(conversation);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch conversation" });
    }
  });

  // Add message to conversation and get AI response
  app.post("/api/calls/:id/message", async (req, res) => {
    try {
      const callId = parseInt(req.params.id);
      const { content } = z.object({
        content: z.string(),
      }).parse(req.body);

      const call = await storage.getCall(callId);
      const conversation = await storage.getConversation(callId);
      
      if (!call || !conversation) {
        return res.status(404).json({ error: "Call or conversation not found" });
      }

      if (call.status !== "active") {
        return res.status(400).json({ error: "Call is not active" });
      }

      // Add customer message
      const customerMessage: Message = {
        id: Date.now().toString(),
        role: "customer",
        content,
        timestamp: new Date().toISOString(),
      };

      const messages = [...(conversation.messages as Message[]), customerMessage];

      // Update call to show AI processing
      await storage.updateCall(callId, { aiProcessing: true });

      broadcast({
        type: "conversation_update",
        data: { callId, messages, aiProcessing: true },
      });

      // Get customer profile for context
      const customerProfile = await storage.getCustomerProfile(call.accountId);
      if (!customerProfile) {
        return res.status(404).json({ error: "Customer profile not found" });
      }

      // Generate AI response
      const aiResponse = await aiAgent.generateResponse(
        messages,
        call.type as CallScenario,
        {
          customerName: customerProfile.name,
          accountId: customerProfile.accountId,
          phone: customerProfile.phone,
          scenario: call.type as CallScenario,
          outstandingBalance: customerProfile.outstandingBalance || undefined,
          lastPaymentDate: customerProfile.lastPaymentDate || undefined,
          accountStatus: customerProfile.accountStatus,
          dateOfBirth: customerProfile.dateOfBirth || undefined,
        }
      );

      // Add AI response
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "ai",
        content: aiResponse.text,
        timestamp: new Date().toISOString(),
      };

      const finalMessages = [...messages, aiMessage];

      // Update conversation and call
      await storage.updateConversation(callId, finalMessages);
      await storage.updateCall(callId, { aiProcessing: false });

      broadcast({
        type: "conversation_update",
        data: { callId, messages: finalMessages, aiProcessing: false },
      });

      res.json({ message: aiMessage });
    } catch (error) {
      console.error("Message processing error:", error);
      
      // Remove AI processing state on error
      const callId = parseInt(req.params.id);
      await storage.updateCall(callId, { aiProcessing: false });
      
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // End call
  app.post("/api/calls/:id/end", async (req, res) => {
    try {
      const callId = parseInt(req.params.id);
      const call = await storage.getCall(callId);
      
      if (!call) {
        return res.status(404).json({ error: "Call not found" });
      }

      const endTime = new Date();
      const duration = Math.floor((endTime.getTime() - call.startTime.getTime()) / 1000);

      // Analyze call outcome
      const conversation = await storage.getConversation(callId);
      let outcome = "Call ended";
      let status = "completed";

      if (conversation && conversation.messages) {
        try {
          const analysis = await aiAgent.analyzeCallOutcome(
            conversation.messages as Message[],
            call.type as CallScenario
          );
          outcome = analysis.outcome;
          status = analysis.success ? "completed" : "failed";
        } catch (error) {
          console.error("Call analysis failed:", error);
        }
      }

      const updatedCall = await storage.updateCall(callId, {
        status,
        endTime,
        duration,
        outcome,
        aiProcessing: false,
      });

      broadcast({
        type: "call_update",
        data: updatedCall,
      });

      res.json(updatedCall);
    } catch (error) {
      console.error("End call error:", error);
      res.status(500).json({ error: "Failed to end call" });
    }
  });

  // Get customer profile
  app.get("/api/customers/:accountId", async (req, res) => {
    try {
      const profile = await storage.getCustomerProfile(req.params.accountId);
      
      if (!profile) {
        return res.status(404).json({ error: "Customer profile not found" });
      }

      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customer profile" });
    }
  });

  return httpServer;
}

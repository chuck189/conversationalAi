import type { CallScenario, Message } from "@shared/schema";

export interface ConversationContext {
  customerName: string;
  accountId: string;
  phone: string;
  scenario: CallScenario;
  outstandingBalance?: number;
  lastPaymentDate?: Date;
  accountStatus?: string;
  dateOfBirth?: Date;
}

export class AIVoiceAgent {
  private getSystemPrompt(scenario: CallScenario, context: ConversationContext): string {
    const basePrompt = `You are a professional AI voice agent for a call center. You should respond in a conversational, helpful, and empathetic manner. Keep responses concise and natural as they represent spoken conversation.

Customer Information:
- Name: ${context.customerName}
- Account ID: ${context.accountId}
- Phone: ${context.phone}`;

    switch (scenario) {
      case "payment":
        return `${basePrompt}
- Outstanding Balance: $${((context.outstandingBalance || 0) / 100).toFixed(2)}
- Last Payment: ${context.lastPaymentDate?.toLocaleDateString() || "Never"}
- Account Status: ${context.accountStatus || "Unknown"}

Scenario: Payment Collection
Your goal is to collect payment for the outstanding balance. Be professional but persistent. Offer payment options and be helpful in resolving the situation. If the customer cannot pay today, try to arrange a payment plan.`;

      case "verification":
        return `${basePrompt}
- Date of Birth: ${context.dateOfBirth?.toLocaleDateString() || "On file"}

Scenario: Identity Verification
Your goal is to verify the customer's identity by asking security questions. Ask for date of birth, account number verification, or other identifying information. Be thorough but efficient.`;

      case "onboarding":
        return `${basePrompt}

Scenario: Account Onboarding
Your goal is to guide the customer through setting up their new account. Collect necessary information, explain services, and ensure they understand how to use their account. Be patient and educational.`;

      case "support":
        return `${basePrompt}
- Account Status: ${context.accountStatus || "Active"}

Scenario: Issue Resolution
Your goal is to help the customer resolve their account issue. Listen to their problem, ask clarifying questions, and provide solutions. If you cannot resolve the issue, explain that you'll escalate to a human agent.`;

      default:
        return `${basePrompt}

Provide helpful customer service assistance.`;
    }
  }

  async generateResponse(
    messages: Message[], 
    scenario: CallScenario, 
    context: ConversationContext
  ): Promise<{ text: string; audioUrl?: string }> {
    try {
      const systemPrompt = this.getSystemPrompt(scenario, context);
      
      // For demo purposes, we'll generate contextual responses based on scenario
      // In a real implementation, this would use a proper conversational AI
      const responses = this.getContextualResponses(scenario, context, messages);
      const responseText = responses[Math.floor(Math.random() * responses.length)];

      // Generate speech using ElevenLabs (placeholder for demo)
      let audioUrl;
      if (process.env.ELEVENLABS_API_KEY && process.env.ELEVENLABS_API_KEY !== "demo_key") {
        try {
          // ElevenLabs integration would go here with proper API key
          // const audioStream = await elevenlabs.generate({ ... });
          audioUrl = `/audio/${Date.now()}.mp3`; // Placeholder URL
        } catch (audioError) {
          console.error("ElevenLabs audio generation error:", audioError);
        }
      }

      return { 
        text: responseText,
        audioUrl 
      };
    } catch (error) {
      console.error("Voice agent error:", error);
      return {
        text: "I apologize, but I'm having trouble responding right now. Let me transfer you to a human agent."
      };
    }
  }

  private getContextualResponses(scenario: CallScenario, context: ConversationContext, messages: Message[]): string[] {
    const customerName = context.customerName.split(' ')[0]; // First name only
    
    switch (scenario) {
      case "payment":
        if (messages.length <= 1) {
          return [
            `Hello ${customerName}, I'm calling about your account. I see you have an outstanding balance of $${((context.outstandingBalance || 0) / 100).toFixed(2)}. Can we discuss payment options today?`,
            `Hi ${customerName}, this is regarding your past due account. I'd like to help you get this resolved. What payment options work best for you?`
          ];
        }
        return [
          `I understand your situation, ${customerName}. We can set up a payment plan that works for your budget. Would you prefer monthly or bi-weekly payments?`,
          `That's perfectly fine, ${customerName}. We have several options available. Would you like to make a partial payment today to get started?`,
          `No problem at all. Let me see what payment arrangements we can offer. What amount would be comfortable for you to start with?`
        ];

      case "verification":
        if (messages.length <= 1) {
          return [
            `Hello ${customerName}, I need to verify your identity for security purposes. Can you please confirm your date of birth?`,
            `Hi ${customerName}, for account security, I need to ask you a few verification questions. What's your date of birth on file?`
          ];
        }
        return [
          `Thank you, ${customerName}. Can you also confirm the last four digits of your phone number on file?`,
          `Perfect. Now, can you tell me your account number or the last payment date for final verification?`,
          `Great, your identity is now verified. How can I assist you with your account today?`
        ];

      case "onboarding":
        if (messages.length <= 1) {
          return [
            `Welcome ${customerName}! I'm excited to help you set up your new account. Let's start with some basic information.`,
            `Hello ${customerName}, congratulations on opening your account with us! I'll guide you through the setup process.`
          ];
        }
        return [
          `Excellent choice, ${customerName}. Now let's set up your account preferences. Would you like to receive notifications by email or text?`,
          `That's all set up, ${customerName}. Next, let's configure your payment method. Do you prefer automatic payments or manual?`,
          `Perfect! Your account is almost ready. Let me explain our key features and how to access your account online.`
        ];

      case "support":
        if (messages.length <= 1) {
          return [
            `Hello ${customerName}, I understand you're having an issue with your account. I'm here to help. Can you describe what's happening?`,
            `Hi ${customerName}, I see you contacted us about an account concern. Let me look into this for you right away.`
          ];
        }
        return [
          `I completely understand your frustration, ${customerName}. Let me check your account details and see how we can resolve this.`,
          `That makes sense, ${customerName}. I'm going to escalate this to our specialist team to ensure it's handled properly.`,
          `I've found the issue, ${customerName}. Here's what happened and how we're going to fix it for you.`
        ];

      default:
        return [`Hello ${customerName}, how can I assist you today?`];
    }
  }

  async analyzeCallOutcome(
    messages: Message[], 
    scenario: CallScenario
  ): Promise<{ outcome: string; success: boolean }> {
    try {
      // Analyze conversation based on scenario and content
      const lastMessages = messages.slice(-3); // Look at last 3 messages
      const customerResponses = lastMessages.filter(m => m.role === "customer");
      
      // Simple analysis based on keywords and context
      let outcome = "Call completed";
      let success = false;

      switch (scenario) {
        case "payment":
          if (customerResponses.some(msg => 
            msg.content.toLowerCase().includes("pay") || 
            msg.content.toLowerCase().includes("payment") ||
            msg.content.toLowerCase().includes("yes")
          )) {
            outcome = "Payment arranged";
            success = true;
          } else {
            outcome = "Payment discussion ongoing";
            success = false;
          }
          break;

        case "verification":
          if (customerResponses.length >= 2) {
            outcome = "Identity verified";
            success = true;
          } else {
            outcome = "Verification in progress";
            success = false;
          }
          break;

        case "onboarding":
          if (messages.length >= 4) {
            outcome = "Account setup completed";
            success = true;
          } else {
            outcome = "Onboarding in progress";
            success = false;
          }
          break;

        case "support":
          if (customerResponses.some(msg => 
            msg.content.toLowerCase().includes("thank") || 
            msg.content.toLowerCase().includes("solved") ||
            msg.content.toLowerCase().includes("fixed")
          )) {
            outcome = "Issue resolved";
            success = true;
          } else {
            outcome = "Issue being investigated";
            success = false;
          }
          break;
      }

      return { outcome, success };
    } catch (error) {
      console.error("Call analysis error:", error);
      return { outcome: "Analysis failed", success: false };
    }
  }
}

export const aiAgent = new AIVoiceAgent();

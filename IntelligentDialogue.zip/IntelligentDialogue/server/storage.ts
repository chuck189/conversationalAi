import { 
  calls, conversations, customerProfiles, callStats, users,
  type Call, type InsertCall, type Conversation, type InsertConversation,
  type CustomerProfile, type InsertCustomerProfile, type CallStats, 
  type InsertCallStats, type User, type InsertUser, type Message
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Call methods
  getCall(id: number): Promise<Call | undefined>;
  getAllCalls(): Promise<Call[]>;
  getActiveCalls(): Promise<Call[]>;
  getRecentCalls(limit?: number): Promise<Call[]>;
  createCall(call: InsertCall): Promise<Call>;
  updateCall(id: number, updates: Partial<Call>): Promise<Call | undefined>;

  // Conversation methods
  getConversation(callId: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(callId: number, messages: Message[]): Promise<Conversation | undefined>;

  // Customer profile methods
  getCustomerProfile(accountId: string): Promise<CustomerProfile | undefined>;
  createCustomerProfile(profile: InsertCustomerProfile): Promise<CustomerProfile>;
  updateCustomerProfile(accountId: string, updates: Partial<CustomerProfile>): Promise<CustomerProfile | undefined>;

  // Stats methods
  getTodayStats(): Promise<CallStats | undefined>;
  updateStats(stats: Partial<CallStats>): Promise<CallStats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private calls: Map<number, Call>;
  private conversations: Map<number, Conversation>;
  private customerProfiles: Map<string, CustomerProfile>;
  private callStats: CallStats;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.calls = new Map();
    this.conversations = new Map();
    this.customerProfiles = new Map();
    this.currentId = 1;

    // Initialize with sample customer profiles
    this.initializeSampleData();

    // Initialize today's stats
    this.callStats = {
      id: 1,
      date: new Date(),
      totalCalls: 1247,
      activeCalls: 24,
      completedCalls: 1223,
      averageHandleTime: 154, // 2:34 in seconds
      resolutionRate: 9420, // 94.20%
    };
  }

  private initializeSampleData() {
    // Sample customer profiles
    const sampleProfiles: InsertCustomerProfile[] = [
      {
        accountId: "AC-789456",
        name: "Sarah Johnson",
        phone: "(555) 123-4567",
        email: "sarah.johnson@email.com",
        accountType: "premium",
        outstandingBalance: 24750, // $247.50
        lastPaymentDate: new Date("2024-10-15"),
        accountStatus: "past_due",
        dateOfBirth: new Date("1985-03-15"),
      },
      {
        accountId: "AC-456789",
        name: "Michael Chen",
        phone: "(555) 234-5678",
        email: "michael.chen@email.com",
        accountType: "standard",
        outstandingBalance: 0,
        lastPaymentDate: new Date("2024-12-01"),
        accountStatus: "active",
        dateOfBirth: new Date("1990-07-22"),
      },
      {
        accountId: "AC-123456",
        name: "Emma Rodriguez",
        phone: "(555) 345-6789",
        email: "emma.rodriguez@email.com",
        accountType: "basic",
        outstandingBalance: 0,
        lastPaymentDate: null,
        accountStatus: "active",
        dateOfBirth: new Date("1992-11-08"),
      },
    ];

    sampleProfiles.forEach(profile => {
      this.customerProfiles.set(profile.accountId, {
        id: this.currentId++,
        ...profile,
        email: profile.email || null,
        outstandingBalance: profile.outstandingBalance || null,
        lastPaymentDate: profile.lastPaymentDate || null,
        dateOfBirth: profile.dateOfBirth || null,
      });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCall(id: number): Promise<Call | undefined> {
    return this.calls.get(id);
  }

  async getAllCalls(): Promise<Call[]> {
    return Array.from(this.calls.values());
  }

  async getActiveCalls(): Promise<Call[]> {
    return Array.from(this.calls.values()).filter(call => call.status === "active");
  }

  async getRecentCalls(limit = 10): Promise<Call[]> {
    return Array.from(this.calls.values())
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime())
      .slice(0, limit);
  }

  async createCall(insertCall: InsertCall): Promise<Call> {
    const id = this.currentId++;
    const call: Call = {
      id,
      ...insertCall,
      outcome: insertCall.outcome || null,
      aiProcessing: insertCall.aiProcessing || false,
      startTime: new Date(),
      endTime: null,
      duration: null,
    };
    this.calls.set(id, call);
    return call;
  }

  async updateCall(id: number, updates: Partial<Call>): Promise<Call | undefined> {
    const call = this.calls.get(id);
    if (!call) return undefined;

    const updatedCall = { ...call, ...updates };
    this.calls.set(id, updatedCall);
    return updatedCall;
  }

  async getConversation(callId: number): Promise<Conversation | undefined> {
    return this.conversations.get(callId);
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.currentId++;
    const conversation: Conversation = {
      id,
      ...insertConversation,
      createdAt: new Date(),
    };
    this.conversations.set(insertConversation.callId, conversation);
    return conversation;
  }

  async updateConversation(callId: number, messages: Message[]): Promise<Conversation | undefined> {
    const conversation = this.conversations.get(callId);
    if (!conversation) return undefined;

    const updatedConversation = { ...conversation, messages };
    this.conversations.set(callId, updatedConversation);
    return updatedConversation;
  }

  async getCustomerProfile(accountId: string): Promise<CustomerProfile | undefined> {
    return this.customerProfiles.get(accountId);
  }

  async createCustomerProfile(insertProfile: InsertCustomerProfile): Promise<CustomerProfile> {
    const id = this.currentId++;
    const profile: CustomerProfile = { 
      id, 
      ...insertProfile,
      email: insertProfile.email || null,
      outstandingBalance: insertProfile.outstandingBalance || null,
      lastPaymentDate: insertProfile.lastPaymentDate || null,
      dateOfBirth: insertProfile.dateOfBirth || null,
    };
    this.customerProfiles.set(insertProfile.accountId, profile);
    return profile;
  }

  async updateCustomerProfile(accountId: string, updates: Partial<CustomerProfile>): Promise<CustomerProfile | undefined> {
    const profile = this.customerProfiles.get(accountId);
    if (!profile) return undefined;

    const updatedProfile = { ...profile, ...updates };
    this.customerProfiles.set(accountId, updatedProfile);
    return updatedProfile;
  }

  async getTodayStats(): Promise<CallStats | undefined> {
    return this.callStats;
  }

  async updateStats(updates: Partial<CallStats>): Promise<CallStats> {
    this.callStats = { ...this.callStats, ...updates };
    return this.callStats;
  }
}

export const storage = new MemStorage();

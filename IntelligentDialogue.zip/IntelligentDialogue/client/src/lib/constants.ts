export const CALL_TYPES = {
  payment: "Payment Collection",
  verification: "Identity Verification", 
  onboarding: "Account Onboarding",
  support: "Issue Resolution",
} as const;

export const CALL_STATUS = {
  active: "Active",
  completed: "Completed",
  failed: "Failed",
  escalated: "Escalated",
} as const;

export const ACCOUNT_STATUS = {
  active: "Active",
  past_due: "Past Due",
  suspended: "Suspended",
} as const;

export const ACCOUNT_TYPES = {
  premium: "Premium",
  standard: "Standard", 
  basic: "Basic",
} as const;

export const formatDuration = (seconds: number): string => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
};

export const formatCurrency = (cents: number): string => {
  return `$${(cents / 100).toFixed(2)}`;
};

export const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
};

export const formatTimeAgo = (date: Date): string => {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return `${diffInSeconds} sec ago`;
  }
  
  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) {
    return `${diffInMinutes} min ago`;
  }
  
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) {
    return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
  }
  
  const diffInDays = Math.floor(diffInHours / 24);
  return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
};

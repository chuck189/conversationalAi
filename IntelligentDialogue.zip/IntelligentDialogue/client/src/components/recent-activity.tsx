import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDuration, formatTimeAgo, getInitials, CALL_TYPES, CALL_STATUS } from "@/lib/constants";
import type { Call } from "@shared/schema";

export default function RecentActivity() {
  const { data: recentCalls, isLoading } = useQuery<Call[]>({
    queryKey: ["/api/calls/recent"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "completed":
        return "default";
      case "failed":
        return "destructive";
      case "escalated":
        return "secondary";
      default:
        return "outline";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-success bg-opacity-10 text-success";
      case "failed":
        return "bg-red-500 bg-opacity-10 text-red-500";
      case "escalated":
        return "bg-warning bg-opacity-10 text-warning";
      default:
        return "bg-gray-500 bg-opacity-10 text-gray-500";
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
            <Button variant="ghost" className="text-primary hover:text-blue-700 text-sm font-medium">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-4"></div>
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-12 bg-gray-200 rounded mb-3"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
          <Button variant="ghost" className="text-primary hover:text-blue-700 text-sm font-medium">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {!recentCalls || recentCalls.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No recent activity</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Customer</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Type</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Duration</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Outcome</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {recentCalls.map((call) => (
                  <tr key={call.id} className="hover:bg-gray-50">
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-xs font-medium text-gray-600">
                            {getInitials(call.customerName)}
                          </span>
                        </div>
                        <span className="font-medium text-gray-900">{call.customerName}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-gray-600">
                      {CALL_TYPES[call.type as keyof typeof CALL_TYPES]}
                    </td>
                    <td className="py-4 px-4 text-gray-600">
                      {call.duration ? formatDuration(call.duration) : "-"}
                    </td>
                    <td className="py-4 px-4">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(call.status)}`}
                      >
                        {CALL_STATUS[call.status as keyof typeof CALL_STATUS]}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-gray-600">{call.outcome || "-"}</td>
                    <td className="py-4 px-4 text-gray-600">
                      {call.endTime ? formatTimeAgo(new Date(call.endTime)) : formatTimeAgo(new Date(call.startTime))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

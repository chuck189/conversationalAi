import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User } from "lucide-react";
import { formatDuration, formatTimeAgo, CALL_TYPES } from "@/lib/constants";
import type { Call } from "@shared/schema";

interface ActiveCallsPanelProps {
  onSelectCall?: (callId: number) => void;
}

export default function ActiveCallsPanel({ onSelectCall }: ActiveCallsPanelProps) {
  const { data: activeCalls, isLoading } = useQuery<Call[]>({
    queryKey: ["/api/calls/active"],
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  const getStatusColor = (type: string) => {
    switch (type) {
      case "payment":
        return "bg-primary";
      case "verification":
        return "bg-warning";
      case "onboarding":
        return "bg-purple-500";
      case "support":
        return "bg-green-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusDot = (type: string) => {
    switch (type) {
      case "payment":
        return "bg-success";
      case "verification":
        return "bg-warning";
      case "onboarding":
        return "bg-purple-500";
      case "support":
        return "bg-green-500";
      default:
        return "bg-gray-500";
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Active Calls</h3>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">Live</span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
                  <div>
                    <div className="h-4 bg-gray-300 rounded w-24 mb-2"></div>
                    <div className="h-3 bg-gray-300 rounded w-16"></div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="h-4 bg-gray-300 rounded w-12 mb-2"></div>
                  <div className="h-3 bg-gray-300 rounded w-16"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Active Calls</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-600">Live</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {!activeCalls || activeCalls.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No active calls at the moment</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activeCalls.map((call) => {
              const duration = call.startTime 
                ? Math.floor((Date.now() - new Date(call.startTime).getTime()) / 1000)
                : 0;
              
              return (
                <div
                  key={call.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                  onClick={() => onSelectCall?.(call.id)}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-10 h-10 ${getStatusColor(call.type)} rounded-full flex items-center justify-center`}>
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{call.customerName}</p>
                      <p className="text-sm text-gray-600">{CALL_TYPES[call.type as keyof typeof CALL_TYPES]}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">{formatDuration(duration)}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className={`w-2 h-2 ${getStatusDot(call.type)} rounded-full`}></div>
                      <span className="text-xs text-gray-600">
                        {call.aiProcessing ? "Processing..." : "In Progress"}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

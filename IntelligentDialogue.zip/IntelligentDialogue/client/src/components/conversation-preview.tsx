import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Send, PhoneOff } from "lucide-react";
import { formatTimeAgo, CALL_TYPES } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Conversation, Call, Message } from "@shared/schema";

interface ConversationPreviewProps {
  callId: number | null;
}

export default function ConversationPreview({ callId }: ConversationPreviewProps) {
  const [customerMessage, setCustomerMessage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: call } = useQuery<Call>({
    queryKey: ["/api/calls", callId],
    enabled: !!callId,
  });

  const { data: conversation, isLoading } = useQuery<Conversation>({
    queryKey: ["/api/calls", callId, "conversation"],
    enabled: !!callId,
    refetchInterval: 2000, // Refetch every 2 seconds
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", `/api/calls/${callId}/message`, { content });
      return await response.json();
    },
    onSuccess: () => {
      setCustomerMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/calls", callId, "conversation"] });
      queryClient.invalidateQueries({ queryKey: ["/api/calls"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const endCallMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/calls/${callId}/end`, {});
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Call Ended",
        description: "Call has been successfully ended",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/calls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to end call",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!customerMessage.trim() || !callId) return;
    sendMessageMutation.mutate(customerMessage.trim());
  };

  const handleEndCall = () => {
    if (!callId) return;
    endCallMutation.mutate();
  };

  if (!callId) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Live Conversation</h3>
          <p className="text-sm text-gray-600 mt-1">Select a call to view conversation</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-center py-8">
            <p className="text-gray-500">No call selected</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Live Conversation</h3>
          <p className="text-sm text-gray-600 mt-1">Loading conversation...</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-center py-8">
            <Loader2 className="w-6 h-6 animate-spin mx-auto text-gray-400" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const messages = (conversation?.messages as Message[]) || [];

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Live Conversation</h3>
        {call && (
          <p className="text-sm text-gray-600 mt-1">
            {call.customerName} - {CALL_TYPES[call.type as keyof typeof CALL_TYPES]}
          </p>
        )}
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {messages.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No messages yet</p>
            </div>
          ) : (
            messages.map((message) => (
              <div key={message.id} className={`flex ${message.role === "ai" ? "justify-start" : "justify-end"}`}>
                <div
                  className={`rounded-lg p-3 max-w-xs ${
                    message.role === "ai"
                      ? "bg-gray-100"
                      : "bg-primary text-white"
                  }`}
                >
                  <p className={`text-sm ${message.role === "ai" ? "text-gray-800" : "text-white"}`}>
                    {message.content}
                  </p>
                  <span
                    className={`text-xs mt-1 block ${
                      message.role === "ai" ? "text-gray-500" : "text-blue-200"
                    }`}
                  >
                    {message.role === "ai" ? "AI Agent" : "Customer"} • {formatTimeAgo(new Date(message.timestamp))}
                  </span>
                </div>
              </div>
            ))
          )}
          
          {call?.aiProcessing && (
            <div className="flex justify-center">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-warning rounded-full animate-pulse"></div>
                  <span className="text-sm text-warning font-medium">AI is processing response...</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Customer Input Interface */}
        {callId && call?.status === "active" && (
          <div className="mt-4 p-4 border-t border-gray-200">
            <div className="flex items-center space-x-2">
              <Input
                value={customerMessage}
                onChange={(e) => setCustomerMessage(e.target.value)}
                placeholder="Type customer response..."
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                disabled={sendMessageMutation.isPending}
                className="flex-1"
              />
              <Button 
                onClick={handleSendMessage}
                disabled={!customerMessage.trim() || sendMessageMutation.isPending}
                size="sm"
              >
                {sendMessageMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
              <Button 
                onClick={handleEndCall}
                disabled={endCallMutation.isPending}
                variant="destructive"
                size="sm"
              >
                {endCallMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <PhoneOff className="w-4 h-4" />
                )}
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Simulate customer responses to test the AI voice agent
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

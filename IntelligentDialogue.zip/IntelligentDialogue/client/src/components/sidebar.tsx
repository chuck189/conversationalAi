import { Mic, BarChart3, Phone, MessageSquare, Settings, Users, ServerCog, Sliders } from "lucide-react";

const navigation = [
  { name: "Dashboard", icon: BarChart3, current: true },
  { name: "Active Calls", icon: Phone, current: false },
  { name: "Conversations", icon: MessageSquare, current: false },
  { name: "Analytics", icon: BarChart3, current: false },
];

const management = [
  { name: "Flow Builder", icon: ServerCog, current: false },
  { name: "Team Management", icon: Users, current: false },
  { name: "Settings", icon: Sliders, current: false },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-secondary text-white flex-shrink-0">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Mic className="w-4 h-4 text-white" />
          </div>
          <h1 className="text-xl font-bold">VoiceAI Pro</h1>
        </div>
      </div>
      
      <nav className="mt-8">
        <div className="px-6 py-2">
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Main</span>
        </div>
        <ul className="space-y-1 px-3">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.name}>
                <a
                  href="#"
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg ${
                    item.current
                      ? "bg-primary bg-opacity-20 text-blue-100"
                      : "text-gray-300 hover:bg-gray-700"
                  }`}
                >
                  <Icon className="w-5 h-5 mr-3" />
                  {item.name}
                </a>
              </li>
            );
          })}
        </ul>

        <div className="px-6 py-2 mt-8">
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Management</span>
        </div>
        <ul className="space-y-1 px-3">
          {management.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.name}>
                <a
                  href="#"
                  className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-300 hover:bg-gray-700"
                >
                  <Icon className="w-5 h-5 mr-3" />
                  {item.name}
                </a>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="absolute bottom-6 left-6 right-6">
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <span className="text-white font-semibold text-sm">JD</span>
            </div>
            <div>
              <p className="text-sm font-medium">John Doe</p>
              <p className="text-xs text-gray-400">Admin</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, TrendingUp, CheckCircle, Clock } from "lucide-react";
import { formatDuration } from "@/lib/constants";
import type { CallStats } from "@shared/schema";

export default function StatsCards() {
  const { data: stats, isLoading } = useQuery<CallStats>({
    queryKey: ["/api/stats"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            No stats available
          </CardContent>
        </Card>
      </div>
    );
  }

  const cards = [
    {
      title: "Active Calls",
      value: stats.activeCalls.toString(),
      change: "+12%",
      changeLabel: "from last hour",
      icon: Phone,
      iconColor: "text-success",
      iconBg: "bg-success bg-opacity-10",
    },
    {
      title: "Calls Today",
      value: stats.totalCalls.toLocaleString(),
      change: "+8%",
      changeLabel: "from yesterday",
      icon: TrendingUp,
      iconColor: "text-primary",
      iconBg: "bg-primary bg-opacity-10",
    },
    {
      title: "Resolution Rate",
      value: `${(stats.resolutionRate / 100).toFixed(1)}%`,
      change: "+2.1%",
      changeLabel: "from last week",
      icon: CheckCircle,
      iconColor: "text-warning",
      iconBg: "bg-warning bg-opacity-10",
    },
    {
      title: "Avg. Handle Time",
      value: formatDuration(stats.averageHandleTime),
      change: "-15s",
      changeLabel: "improvement",
      icon: Clock,
      iconColor: "text-red-500",
      iconBg: "bg-red-500 bg-opacity-10",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <Card key={card.title} className="shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{card.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{card.value}</p>
                </div>
                <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${card.iconColor} w-6 h-6`} />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className="text-success text-sm font-medium">{card.change}</span>
                <span className="text-gray-600 text-sm ml-2">{card.changeLabel}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

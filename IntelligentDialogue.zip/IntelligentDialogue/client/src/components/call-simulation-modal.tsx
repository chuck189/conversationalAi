import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Play, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, ACCOUNT_STATUS, ACCOUNT_TYPES, CALL_TYPES } from "@/lib/constants";
import type { CustomerProfile, CallScenario } from "@shared/schema";

interface CallSimulationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCallStarted?: (callId: number) => void;
}

export default function CallSimulationModal({ isOpen, onClose, onCallStarted }: CallSimulationModalProps) {
  const [selectedScenario, setSelectedScenario] = useState<CallScenario>("payment");
  const [selectedAccountId, setSelectedAccountId] = useState("AC-789456");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // For simplicity, we'll use hardcoded customer profiles
  // In a real app, this would be fetched from the API
  const customerProfiles: CustomerProfile[] = [
    {
      id: 1,
      accountId: "AC-789456",
      name: "Sarah Johnson",
      phone: "(555) 123-4567",
      email: "sarah.johnson@email.com",
      accountType: "premium",
      outstandingBalance: 24750,
      lastPaymentDate: new Date("2024-10-15"),
      accountStatus: "past_due",
      dateOfBirth: new Date("1985-03-15"),
    },
    {
      id: 2,
      accountId: "AC-456789",
      name: "Michael Chen",
      phone: "(555) 234-5678",
      email: "michael.chen@email.com",
      accountType: "standard",
      outstandingBalance: 0,
      lastPaymentDate: new Date("2024-12-01"),
      accountStatus: "active",
      dateOfBirth: new Date("1990-07-22"),
    },
    {
      id: 3,
      accountId: "AC-123456",
      name: "Emma Rodriguez",
      phone: "(555) 345-6789",
      email: "emma.rodriguez@email.com",
      accountType: "basic",
      outstandingBalance: 0,
      lastPaymentDate: null,
      accountStatus: "active",
      dateOfBirth: new Date("1992-11-08"),
    },
  ];

  const selectedProfile = customerProfiles.find(p => p.accountId === selectedAccountId);

  const startCallMutation = useMutation({
    mutationFn: async (data: { accountId: string; scenario: CallScenario }) => {
      const response = await apiRequest("POST", "/api/calls/start", data);
      return await response.json();
    },
    onSuccess: (call) => {
      toast({
        title: "Call Started",
        description: `Call simulation started with ${call.customerName}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/calls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onCallStarted?.(call.id);
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to start call simulation",
        variant: "destructive",
      });
      console.error("Start call error:", error);
    },
  });

  const handleStartSimulation = () => {
    if (!selectedProfile) return;
    
    startCallMutation.mutate({
      accountId: selectedAccountId,
      scenario: selectedScenario,
    });
  };

  const scenarios = [
    {
      value: "payment" as const,
      title: "Payment Collection",
      description: "Collect overdue payment from customer",
    },
    {
      value: "verification" as const,
      title: "Identity Verification",
      description: "Verify customer identity and account details",
    },
    {
      value: "onboarding" as const,
      title: "Account Onboarding",
      description: "Guide new customer through account setup",
    },
    {
      value: "support" as const,
      title: "Issue Resolution",
      description: "Help customer resolve account issues",
    },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Call Simulation</DialogTitle>
          <p className="text-gray-600 mt-2">Test your AI voice agent with different scenarios</p>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          {/* Scenario Selection */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Select Scenario</h4>
            <RadioGroup value={selectedScenario} onValueChange={(value) => setSelectedScenario(value as CallScenario)}>
              <div className="space-y-3">
                {scenarios.map((scenario) => (
                  <div key={scenario.value}>
                    <Label
                      htmlFor={scenario.value}
                      className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
                    >
                      <RadioGroupItem value={scenario.value} id={scenario.value} className="mr-3" />
                      <div>
                        <p className="font-medium text-gray-900">{scenario.title}</p>
                        <p className="text-sm text-gray-600">{scenario.description}</p>
                      </div>
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
            
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 mb-4">Select Customer</h4>
              <RadioGroup value={selectedAccountId} onValueChange={setSelectedAccountId}>
                <div className="space-y-3">
                  {customerProfiles.map((profile) => (
                    <div key={profile.accountId}>
                      <Label
                        htmlFor={profile.accountId}
                        className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
                      >
                        <RadioGroupItem value={profile.accountId} id={profile.accountId} className="mr-3" />
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{profile.name}</p>
                          <p className="text-sm text-gray-600">{profile.accountId}</p>
                        </div>
                        <Badge variant={profile.accountStatus === "past_due" ? "destructive" : "default"}>
                          {ACCOUNT_STATUS[profile.accountStatus as keyof typeof ACCOUNT_STATUS]}
                        </Badge>
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
            
            <Button 
              onClick={handleStartSimulation}
              disabled={startCallMutation.isPending}
              className="w-full mt-6 bg-primary hover:bg-blue-700"
            >
              {startCallMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Starting...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Start Simulation
                </>
              )}
            </Button>
          </div>
          
          {/* Customer Profile */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Customer Profile</h4>
            {selectedProfile && (
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {selectedProfile.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-900">{selectedProfile.name}</h5>
                    <p className="text-gray-600">
                      {ACCOUNT_TYPES[selectedProfile.accountType as keyof typeof ACCOUNT_TYPES]} Customer
                    </p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Account ID:</span>
                    <span className="font-medium">{selectedProfile.accountId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Phone:</span>
                    <span className="font-medium">{selectedProfile.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Outstanding Balance:</span>
                    <span className={`font-medium ${selectedProfile.outstandingBalance > 0 ? 'text-red-500' : 'text-green-500'}`}>
                      {formatCurrency(selectedProfile.outstandingBalance)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Payment:</span>
                    <span className="font-medium">
                      {selectedProfile.lastPaymentDate 
                        ? selectedProfile.lastPaymentDate.toLocaleDateString()
                        : "Never"
                      }
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Account Status:</span>
                    <Badge variant={selectedProfile.accountStatus === "past_due" ? "destructive" : "default"}>
                      {ACCOUNT_STATUS[selectedProfile.accountStatus as keyof typeof ACCOUNT_STATUS]}
                    </Badge>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

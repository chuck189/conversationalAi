import { useState, useCallback } from "react";
import Sidebar from "@/components/sidebar";
import StatsCards from "@/components/stats-cards";
import ActiveCallsPanel from "@/components/active-calls-panel";
import ConversationPreview from "@/components/conversation-preview";
import RecentActivity from "@/components/recent-activity";
import CallSimulationModal from "@/components/call-simulation-modal";
import { Button } from "@/components/ui/button";
import { Bell, Plus } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import type { WSMessage } from "@shared/schema";

export default function Dashboard() {
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [selectedCallId, setSelectedCallId] = useState<number | null>(null);

  const handleWebSocketMessage = useCallback((message: WSMessage) => {
    console.log("WebSocket message received:", message);
    // This will trigger re-renders in components that use React Query
    // as they will refetch their data
  }, []);

  const { isConnected } = useWebSocket(handleWebSocketMessage);

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
              <p className="text-gray-600 mt-1">Monitor your AI voice agents and call center performance</p>
            </div>
            <div className="flex items-center space-x-4">
              <Button onClick={() => setIsCallModalOpen(true)} className="bg-primary hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Start Test Call
              </Button>
              <div className="relative">
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-gray-600">
                  <Bell className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                    3
                  </span>
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
                <span className="text-xs text-gray-600">{isConnected ? 'Connected' : 'Disconnected'}</span>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="p-6 overflow-y-auto h-full">
          <StatsCards />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
            <div className="lg:col-span-2">
              <ActiveCallsPanel onSelectCall={setSelectedCallId} />
            </div>
            <div>
              <ConversationPreview callId={selectedCallId} />
            </div>
          </div>

          <div className="mt-8">
            <RecentActivity />
          </div>
        </div>
      </main>

      <CallSimulationModal 
        isOpen={isCallModalOpen} 
        onClose={() => setIsCallModalOpen(false)}
        onCallStarted={(callId) => {
          setSelectedCallId(callId);
          setIsCallModalOpen(false);
        }}
      />
    </div>
  );
}

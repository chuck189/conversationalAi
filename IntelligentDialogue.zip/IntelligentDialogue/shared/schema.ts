import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const calls = pgTable("calls", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  accountId: text("account_id").notNull(),
  type: text("type").notNull(), // "payment", "verification", "onboarding", "support"
  status: text("status").notNull(), // "active", "completed", "failed", "escalated"
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in seconds
  outcome: text("outcome"),
  aiProcessing: boolean("ai_processing").default(false),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  callId: integer("call_id").notNull(),
  messages: jsonb("messages").notNull(), // Array of message objects
  createdAt: timestamp("created_at").defaultNow(),
});

export const customerProfiles = pgTable("customer_profiles", {
  id: serial("id").primaryKey(),
  accountId: text("account_id").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  accountType: text("account_type").notNull(), // "premium", "standard", "basic"
  outstandingBalance: integer("outstanding_balance").default(0), // in cents
  lastPaymentDate: timestamp("last_payment_date"),
  accountStatus: text("account_status").notNull(), // "active", "past_due", "suspended"
  dateOfBirth: timestamp("date_of_birth"),
});

export const callStats = pgTable("call_stats", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  totalCalls: integer("total_calls").default(0),
  activeCalls: integer("active_calls").default(0),
  completedCalls: integer("completed_calls").default(0),
  averageHandleTime: integer("average_handle_time").default(0), // in seconds
  resolutionRate: integer("resolution_rate").default(0), // percentage * 100
});

// Insert schemas
export const insertCallSchema = createInsertSchema(calls).omit({
  id: true,
  startTime: true,
  endTime: true,
  duration: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
});

export const insertCustomerProfileSchema = createInsertSchema(customerProfiles).omit({
  id: true,
});

export const insertCallStatsSchema = createInsertSchema(callStats).omit({
  id: true,
});

// Types
export type InsertCall = z.infer<typeof insertCallSchema>;
export type Call = typeof calls.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertCustomerProfile = z.infer<typeof insertCustomerProfileSchema>;
export type CustomerProfile = typeof customerProfiles.$inferSelect;
export type InsertCallStats = z.infer<typeof insertCallStatsSchema>;
export type CallStats = typeof callStats.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Message type for conversations
export type Message = {
  id: string;
  role: "ai" | "customer";
  content: string;
  timestamp: string;
};

// Call scenario types
export type CallScenario = "payment" | "verification" | "onboarding" | "support";

// WebSocket message types
export type WSMessage = {
  type: "call_update" | "conversation_update" | "stats_update" | "new_call";
  data: any;
};
